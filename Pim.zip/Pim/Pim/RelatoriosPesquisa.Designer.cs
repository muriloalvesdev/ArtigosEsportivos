﻿namespace Pim3Semestre_Original_
{
    partial class TelaPesquisar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaPesquisar));
            this.btnPesquisarCliente = new System.Windows.Forms.Button();
            this.btnPesquisarProduto = new System.Windows.Forms.Button();
            this.btnPesquisarFornecedor = new System.Windows.Forms.Button();
            this.panelDashboardPesquisar = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panelFornecedor = new System.Windows.Forms.Panel();
            this.dataGridViewFornecedor = new System.Windows.Forms.DataGridView();
            this.btnBuscarFornecedor = new System.Windows.Forms.Button();
            this.maskedTextBoxCnpj = new System.Windows.Forms.MaskedTextBox();
            this.textBoxNomeFornecedor = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panelProduto = new System.Windows.Forms.Panel();
            this.btnBuscarProduto = new System.Windows.Forms.Button();
            this.dataGridViewProdutos = new System.Windows.Forms.DataGridView();
            this.textBoxNomeProduto = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panelCliente = new System.Windows.Forms.Panel();
            this.btnBuscarCliente = new System.Windows.Forms.Button();
            this.dataGridViewCliente = new System.Windows.Forms.DataGridView();
            this.maskedTextBoxCpf = new System.Windows.Forms.MaskedTextBox();
            this.textBoxNomeCliente = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnCloseFecharTelaDePEsquisa = new System.Windows.Forms.Button();
            this.panelDashboardPesquisar.SuspendLayout();
            this.panelFornecedor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFornecedor)).BeginInit();
            this.panelProduto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProdutos)).BeginInit();
            this.panelCliente.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCliente)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPesquisarCliente
            // 
            this.btnPesquisarCliente.BackColor = System.Drawing.Color.Transparent;
            this.btnPesquisarCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPesquisarCliente.FlatAppearance.BorderSize = 0;
            this.btnPesquisarCliente.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnPesquisarCliente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnPesquisarCliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnPesquisarCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPesquisarCliente.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPesquisarCliente.ForeColor = System.Drawing.Color.White;
            this.btnPesquisarCliente.Location = new System.Drawing.Point(30, 238);
            this.btnPesquisarCliente.Margin = new System.Windows.Forms.Padding(4);
            this.btnPesquisarCliente.Name = "btnPesquisarCliente";
            this.btnPesquisarCliente.Size = new System.Drawing.Size(136, 32);
            this.btnPesquisarCliente.TabIndex = 0;
            this.btnPesquisarCliente.Text = "Cliente";
            this.btnPesquisarCliente.UseVisualStyleBackColor = false;
            this.btnPesquisarCliente.Click += new System.EventHandler(this.btnPesquisarCliente_Click);
            // 
            // btnPesquisarProduto
            // 
            this.btnPesquisarProduto.BackColor = System.Drawing.Color.Transparent;
            this.btnPesquisarProduto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPesquisarProduto.FlatAppearance.BorderSize = 0;
            this.btnPesquisarProduto.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnPesquisarProduto.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnPesquisarProduto.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnPesquisarProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPesquisarProduto.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPesquisarProduto.ForeColor = System.Drawing.Color.White;
            this.btnPesquisarProduto.Location = new System.Drawing.Point(30, 294);
            this.btnPesquisarProduto.Margin = new System.Windows.Forms.Padding(4);
            this.btnPesquisarProduto.Name = "btnPesquisarProduto";
            this.btnPesquisarProduto.Size = new System.Drawing.Size(147, 32);
            this.btnPesquisarProduto.TabIndex = 1;
            this.btnPesquisarProduto.Text = "Produto";
            this.btnPesquisarProduto.UseVisualStyleBackColor = false;
            this.btnPesquisarProduto.Click += new System.EventHandler(this.btnPesquisarProduto_Click);
            // 
            // btnPesquisarFornecedor
            // 
            this.btnPesquisarFornecedor.BackColor = System.Drawing.Color.Transparent;
            this.btnPesquisarFornecedor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPesquisarFornecedor.FlatAppearance.BorderSize = 0;
            this.btnPesquisarFornecedor.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnPesquisarFornecedor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnPesquisarFornecedor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnPesquisarFornecedor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPesquisarFornecedor.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPesquisarFornecedor.ForeColor = System.Drawing.Color.White;
            this.btnPesquisarFornecedor.Location = new System.Drawing.Point(39, 182);
            this.btnPesquisarFornecedor.Margin = new System.Windows.Forms.Padding(4);
            this.btnPesquisarFornecedor.Name = "btnPesquisarFornecedor";
            this.btnPesquisarFornecedor.Size = new System.Drawing.Size(154, 32);
            this.btnPesquisarFornecedor.TabIndex = 2;
            this.btnPesquisarFornecedor.Text = "Fornecedor";
            this.btnPesquisarFornecedor.UseVisualStyleBackColor = false;
            this.btnPesquisarFornecedor.Click += new System.EventHandler(this.btnPesquisarFornecedor_Click);
            // 
            // panelDashboardPesquisar
            // 
            this.panelDashboardPesquisar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelDashboardPesquisar.BackgroundImage")));
            this.panelDashboardPesquisar.Controls.Add(this.label1);
            this.panelDashboardPesquisar.Controls.Add(this.btnPesquisarFornecedor);
            this.panelDashboardPesquisar.Controls.Add(this.btnPesquisarProduto);
            this.panelDashboardPesquisar.Controls.Add(this.btnPesquisarCliente);
            this.panelDashboardPesquisar.Location = new System.Drawing.Point(-2, 5);
            this.panelDashboardPesquisar.Name = "panelDashboardPesquisar";
            this.panelDashboardPesquisar.Size = new System.Drawing.Size(240, 774);
            this.panelDashboardPesquisar.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(32, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 39);
            this.label1.TabIndex = 3;
            this.label1.Text = "Pesquisar";
            // 
            // panelFornecedor
            // 
            this.panelFornecedor.Controls.Add(this.dataGridViewFornecedor);
            this.panelFornecedor.Controls.Add(this.btnBuscarFornecedor);
            this.panelFornecedor.Controls.Add(this.maskedTextBoxCnpj);
            this.panelFornecedor.Controls.Add(this.textBoxNomeFornecedor);
            this.panelFornecedor.Controls.Add(this.label3);
            this.panelFornecedor.Controls.Add(this.label2);
            this.panelFornecedor.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelFornecedor.Location = new System.Drawing.Point(298, 141);
            this.panelFornecedor.Name = "panelFornecedor";
            this.panelFornecedor.Size = new System.Drawing.Size(725, 537);
            this.panelFornecedor.TabIndex = 4;
            // 
            // dataGridViewFornecedor
            // 
            this.dataGridViewFornecedor.BackgroundColor = System.Drawing.SystemColors.Menu;
            this.dataGridViewFornecedor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFornecedor.Location = new System.Drawing.Point(12, 122);
            this.dataGridViewFornecedor.Name = "dataGridViewFornecedor";
            this.dataGridViewFornecedor.Size = new System.Drawing.Size(710, 407);
            this.dataGridViewFornecedor.TabIndex = 4;
            // 
            // btnBuscarFornecedor
            // 
            this.btnBuscarFornecedor.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBuscarFornecedor.BackgroundImage")));
            this.btnBuscarFornecedor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnBuscarFornecedor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarFornecedor.FlatAppearance.BorderSize = 0;
            this.btnBuscarFornecedor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuscarFornecedor.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarFornecedor.Location = new System.Drawing.Point(470, 80);
            this.btnBuscarFornecedor.Name = "btnBuscarFornecedor";
            this.btnBuscarFornecedor.Size = new System.Drawing.Size(103, 36);
            this.btnBuscarFornecedor.TabIndex = 3;
            this.btnBuscarFornecedor.Text = "Pesquisar";
            this.btnBuscarFornecedor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarFornecedor.UseVisualStyleBackColor = true;
            this.btnBuscarFornecedor.Click += new System.EventHandler(this.btnBuscarFornecedor_Click);
            // 
            // maskedTextBoxCnpj
            // 
            this.maskedTextBoxCnpj.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxCnpj.Location = new System.Drawing.Point(59, 88);
            this.maskedTextBoxCnpj.Name = "maskedTextBoxCnpj";
            this.maskedTextBoxCnpj.Size = new System.Drawing.Size(107, 22);
            this.maskedTextBoxCnpj.TabIndex = 2;
            // 
            // textBoxNomeFornecedor
            // 
            this.textBoxNomeFornecedor.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNomeFornecedor.Location = new System.Drawing.Point(59, 53);
            this.textBoxNomeFornecedor.Name = "textBoxNomeFornecedor";
            this.textBoxNomeFornecedor.Size = new System.Drawing.Size(193, 22);
            this.textBoxNomeFornecedor.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "CNPJ:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nome: ";
            // 
            // panelProduto
            // 
            this.panelProduto.BackColor = System.Drawing.Color.White;
            this.panelProduto.Controls.Add(this.btnBuscarProduto);
            this.panelProduto.Controls.Add(this.dataGridViewProdutos);
            this.panelProduto.Controls.Add(this.textBoxNomeProduto);
            this.panelProduto.Controls.Add(this.label7);
            this.panelProduto.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelProduto.Location = new System.Drawing.Point(304, 129);
            this.panelProduto.Name = "panelProduto";
            this.panelProduto.Size = new System.Drawing.Size(567, 496);
            this.panelProduto.TabIndex = 7;
            // 
            // btnBuscarProduto
            // 
            this.btnBuscarProduto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBuscarProduto.BackgroundImage")));
            this.btnBuscarProduto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnBuscarProduto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarProduto.FlatAppearance.BorderSize = 0;
            this.btnBuscarProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuscarProduto.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarProduto.Location = new System.Drawing.Point(407, 57);
            this.btnBuscarProduto.Name = "btnBuscarProduto";
            this.btnBuscarProduto.Size = new System.Drawing.Size(103, 36);
            this.btnBuscarProduto.TabIndex = 2;
            this.btnBuscarProduto.Text = "Pesquisar";
            this.btnBuscarProduto.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarProduto.UseVisualStyleBackColor = true;
            this.btnBuscarProduto.Click += new System.EventHandler(this.btnBuscarProduto_Click);
            // 
            // dataGridViewProdutos
            // 
            this.dataGridViewProdutos.AllowUserToAddRows = false;
            this.dataGridViewProdutos.AllowUserToDeleteRows = false;
            this.dataGridViewProdutos.BackgroundColor = System.Drawing.SystemColors.Menu;
            this.dataGridViewProdutos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProdutos.Location = new System.Drawing.Point(6, 93);
            this.dataGridViewProdutos.Name = "dataGridViewProdutos";
            this.dataGridViewProdutos.ReadOnly = true;
            this.dataGridViewProdutos.Size = new System.Drawing.Size(561, 395);
            this.dataGridViewProdutos.TabIndex = 10;
            // 
            // textBoxNomeProduto
            // 
            this.textBoxNomeProduto.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNomeProduto.Location = new System.Drawing.Point(59, 65);
            this.textBoxNomeProduto.Name = "textBoxNomeProduto";
            this.textBoxNomeProduto.Size = new System.Drawing.Size(193, 22);
            this.textBoxNomeProduto.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 65);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Nome: ";
            // 
            // panelCliente
            // 
            this.panelCliente.Controls.Add(this.btnBuscarCliente);
            this.panelCliente.Controls.Add(this.dataGridViewCliente);
            this.panelCliente.Controls.Add(this.maskedTextBoxCpf);
            this.panelCliente.Controls.Add(this.textBoxNomeCliente);
            this.panelCliente.Controls.Add(this.label4);
            this.panelCliente.Controls.Add(this.label5);
            this.panelCliente.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelCliente.Location = new System.Drawing.Point(292, 154);
            this.panelCliente.Name = "panelCliente";
            this.panelCliente.Size = new System.Drawing.Size(745, 516);
            this.panelCliente.TabIndex = 6;
            // 
            // btnBuscarCliente
            // 
            this.btnBuscarCliente.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBuscarCliente.BackgroundImage")));
            this.btnBuscarCliente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnBuscarCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarCliente.FlatAppearance.BorderSize = 0;
            this.btnBuscarCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuscarCliente.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarCliente.Location = new System.Drawing.Point(454, 60);
            this.btnBuscarCliente.Name = "btnBuscarCliente";
            this.btnBuscarCliente.Size = new System.Drawing.Size(103, 36);
            this.btnBuscarCliente.TabIndex = 3;
            this.btnBuscarCliente.Text = "Pesquisar";
            this.btnBuscarCliente.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarCliente.UseVisualStyleBackColor = true;
            this.btnBuscarCliente.Click += new System.EventHandler(this.btnBuscarCliente_Click);
            // 
            // dataGridViewCliente
            // 
            this.dataGridViewCliente.AllowUserToAddRows = false;
            this.dataGridViewCliente.AllowUserToDeleteRows = false;
            this.dataGridViewCliente.BackgroundColor = System.Drawing.SystemColors.Menu;
            this.dataGridViewCliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCliente.Location = new System.Drawing.Point(6, 96);
            this.dataGridViewCliente.Name = "dataGridViewCliente";
            this.dataGridViewCliente.ReadOnly = true;
            this.dataGridViewCliente.Size = new System.Drawing.Size(725, 411);
            this.dataGridViewCliente.TabIndex = 10;
            // 
            // maskedTextBoxCpf
            // 
            this.maskedTextBoxCpf.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxCpf.Location = new System.Drawing.Point(59, 68);
            this.maskedTextBoxCpf.Name = "maskedTextBoxCpf";
            this.maskedTextBoxCpf.Size = new System.Drawing.Size(107, 22);
            this.maskedTextBoxCpf.TabIndex = 2;
            // 
            // textBoxNomeCliente
            // 
            this.textBoxNomeCliente.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNomeCliente.Location = new System.Drawing.Point(59, 34);
            this.textBoxNomeCliente.Name = "textBoxNomeCliente";
            this.textBoxNomeCliente.Size = new System.Drawing.Size(193, 22);
            this.textBoxNomeCliente.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "CPF:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 16);
            this.label5.TabIndex = 6;
            this.label5.Text = "Nome: ";
            // 
            // btnCloseFecharTelaDePEsquisa
            // 
            this.btnCloseFecharTelaDePEsquisa.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCloseFecharTelaDePEsquisa.BackgroundImage")));
            this.btnCloseFecharTelaDePEsquisa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCloseFecharTelaDePEsquisa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCloseFecharTelaDePEsquisa.FlatAppearance.BorderSize = 0;
            this.btnCloseFecharTelaDePEsquisa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloseFecharTelaDePEsquisa.Location = new System.Drawing.Point(1006, 12);
            this.btnCloseFecharTelaDePEsquisa.Name = "btnCloseFecharTelaDePEsquisa";
            this.btnCloseFecharTelaDePEsquisa.Size = new System.Drawing.Size(46, 40);
            this.btnCloseFecharTelaDePEsquisa.TabIndex = 8;
            this.btnCloseFecharTelaDePEsquisa.UseVisualStyleBackColor = true;
            this.btnCloseFecharTelaDePEsquisa.Click += new System.EventHandler(this.btnCloseFecharTelaDePEsquisa_Click);
            // 
            // TelaPesquisar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1064, 677);
            this.Controls.Add(this.panelFornecedor);
            this.Controls.Add(this.panelProduto);
            this.Controls.Add(this.panelCliente);
            this.Controls.Add(this.btnCloseFecharTelaDePEsquisa);
            this.Controls.Add(this.panelDashboardPesquisar);
            this.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(250, 40);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "TelaPesquisar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "TelaPesquisar";
            this.panelDashboardPesquisar.ResumeLayout(false);
            this.panelDashboardPesquisar.PerformLayout();
            this.panelFornecedor.ResumeLayout(false);
            this.panelFornecedor.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFornecedor)).EndInit();
            this.panelProduto.ResumeLayout(false);
            this.panelProduto.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProdutos)).EndInit();
            this.panelCliente.ResumeLayout(false);
            this.panelCliente.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCliente)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPesquisarCliente;
        private System.Windows.Forms.Button btnPesquisarProduto;
        private System.Windows.Forms.Button btnPesquisarFornecedor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBuscarFornecedor;
        private System.Windows.Forms.Button btnBuscarCliente;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxCpf;
        private System.Windows.Forms.TextBox textBoxNomeCliente;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridViewCliente;
        private System.Windows.Forms.Button btnBuscarProduto;
        private System.Windows.Forms.DataGridView dataGridViewProdutos;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.Panel panelDashboardPesquisar;
        private System.Windows.Forms.Panel panelFornecedor;
        private System.Windows.Forms.Panel panelCliente;
        private System.Windows.Forms.Panel panelProduto;
        private System.Windows.Forms.Button btnCloseFecharTelaDePEsquisa;
        public System.Windows.Forms.TextBox textBoxNomeFornecedor;
        public System.Windows.Forms.MaskedTextBox maskedTextBoxCnpj;
        public System.Windows.Forms.DataGridView dataGridViewFornecedor;
        public System.Windows.Forms.TextBox textBoxNomeProduto;
    }
}