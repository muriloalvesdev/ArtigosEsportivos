﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim3Semestre_Original_.Classes
{
    public class Clientes
    {
        public int id_cliente { get; set; }
        public String nome { get; set; }
        public String cpf { get; set; }
        public String dataNascimento { get; set; }
        public String sexo { get; set; }
        public String cep { get; set; }
        public String logradouro { get; set; }
        public String cidade { get; set; }
        public String uf { get; set; }
        public String complemento { get; set; }
        public String celular  { get; set; }
        public String telfixo { get; set; }
        public String bairro { get; set; }
    }
}