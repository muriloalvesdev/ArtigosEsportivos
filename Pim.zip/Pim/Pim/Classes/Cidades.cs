﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim3Semestre_Original_.Classes
{
    public class Cidades
    {
        public String nome { get; set; }
        public String id_cidade { get; set; }
    }
}
