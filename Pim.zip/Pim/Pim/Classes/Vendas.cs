﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim3Semestre_Original_.Classes
{
    public class Vendas
    {
        public String id_produto { get; set; }
        public String nome { get; set; }
        public String precoUnidade { get; set; }
        public String quantidade { get; set; }
        public String modelo { get; set; }
        public String total { get; set; }
        public String valorCompra { get; set; }
        public String id_funcionario { get; set; }
        public String dia { get; set; }
    }
}
