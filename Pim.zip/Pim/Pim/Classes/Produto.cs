﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim3Semestre_Original_.Classes
{
    public class Produto
    {
        public int idProduto { get; set; }
        public String nome { get; set; }
        public String precoVenda { get; set; }
        public String precoCusto { get; set; }
        public String quantidade { get; set; }
        public String descricao { get; set; }
        public String modelo { get; set; }
    }
}