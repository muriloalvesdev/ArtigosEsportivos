﻿namespace Pim3Semestre_Original_
{
    partial class BtnCaixa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BtnCaixa));
            this.lblTextCodVenda = new System.Windows.Forms.Label();
            this.lblTxtnomeProduto = new System.Windows.Forms.Label();
            this.textBoxNomeProd = new System.Windows.Forms.TextBox();
            this.lblTextValorUnitario = new System.Windows.Forms.Label();
            this.dataGridViewProdutosCaixa = new System.Windows.Forms.DataGridView();
            this.textBoxlValorUnitario = new System.Windows.Forms.TextBox();
            this.btnFecharCaixa = new System.Windows.Forms.Button();
            this.textBoxCodProduto = new System.Windows.Forms.TextBox();
            this.lblTotalVenda = new System.Windows.Forms.Label();
            this.maskedTextBoxValorTotalVenda = new System.Windows.Forms.MaskedTextBox();
            this.btnAdicionarProduto = new System.Windows.Forms.Button();
            this.btnFinalizarCompra = new System.Windows.Forms.Button();
            this.lblPesquisar = new System.Windows.Forms.Label();
            this.btnFecharJanela = new System.Windows.Forms.Button();
            this.lblTextCaixaAberto = new System.Windows.Forms.Label();
            this.btnAdicionarProdutosEsquerda = new System.Windows.Forms.Button();
            this.lblQuantidade = new System.Windows.Forms.Label();
            this.textBoxlQuantidadeProduto = new System.Windows.Forms.TextBox();
            this.comboBoxProdutos = new System.Windows.Forms.ComboBox();
            this.btnExcluirVenda = new System.Windows.Forms.Button();
            this.lblCodCaixa = new System.Windows.Forms.Label();
            this.lblTextTotal = new System.Windows.Forms.Label();
            this.textBoxTotalVendaCompleta = new System.Windows.Forms.TextBox();
            this.btnFinalizarVenda = new System.Windows.Forms.Button();
            this.lblFormaPagamento = new System.Windows.Forms.Label();
            this.comboBoxFormaPagamento = new System.Windows.Forms.ComboBox();
            this.lblPagamento = new System.Windows.Forms.Label();
            this.textBoxValorPagamento = new System.Windows.Forms.TextBox();
            this.lblTroco = new System.Windows.Forms.Label();
            this.textBoxTroco = new System.Windows.Forms.TextBox();
            this.textBoxTotalVenda = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProdutosCaixa)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTextCodVenda
            // 
            this.lblTextCodVenda.AutoSize = true;
            this.lblTextCodVenda.BackColor = System.Drawing.Color.Transparent;
            this.lblTextCodVenda.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTextCodVenda.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblTextCodVenda.Location = new System.Drawing.Point(15, 207);
            this.lblTextCodVenda.Name = "lblTextCodVenda";
            this.lblTextCodVenda.Size = new System.Drawing.Size(70, 19);
            this.lblTextCodVenda.TabIndex = 0;
            this.lblTextCodVenda.Text = "Código: ";
            // 
            // lblTxtnomeProduto
            // 
            this.lblTxtnomeProduto.AutoSize = true;
            this.lblTxtnomeProduto.BackColor = System.Drawing.Color.Transparent;
            this.lblTxtnomeProduto.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTxtnomeProduto.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblTxtnomeProduto.Location = new System.Drawing.Point(15, 248);
            this.lblTxtnomeProduto.Name = "lblTxtnomeProduto";
            this.lblTxtnomeProduto.Size = new System.Drawing.Size(71, 19);
            this.lblTxtnomeProduto.TabIndex = 2;
            this.lblTxtnomeProduto.Text = "Produto:";
            // 
            // textBoxNomeProd
            // 
            this.textBoxNomeProd.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNomeProd.Location = new System.Drawing.Point(116, 249);
            this.textBoxNomeProd.Name = "textBoxNomeProd";
            this.textBoxNomeProd.Size = new System.Drawing.Size(111, 22);
            this.textBoxNomeProd.TabIndex = 2;
            // 
            // lblTextValorUnitario
            // 
            this.lblTextValorUnitario.AutoSize = true;
            this.lblTextValorUnitario.BackColor = System.Drawing.Color.Transparent;
            this.lblTextValorUnitario.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTextValorUnitario.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblTextValorUnitario.Location = new System.Drawing.Point(14, 327);
            this.lblTextValorUnitario.Name = "lblTextValorUnitario";
            this.lblTextValorUnitario.Size = new System.Drawing.Size(95, 19);
            this.lblTextValorUnitario.TabIndex = 7;
            this.lblTextValorUnitario.Text = "Valor Unid: ";
            // 
            // dataGridViewProdutosCaixa
            // 
            this.dataGridViewProdutosCaixa.AllowUserToAddRows = false;
            this.dataGridViewProdutosCaixa.AllowUserToDeleteRows = false;
            this.dataGridViewProdutosCaixa.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridViewProdutosCaixa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProdutosCaixa.Location = new System.Drawing.Point(378, 208);
            this.dataGridViewProdutosCaixa.Name = "dataGridViewProdutosCaixa";
            this.dataGridViewProdutosCaixa.ReadOnly = true;
            this.dataGridViewProdutosCaixa.Size = new System.Drawing.Size(547, 353);
            this.dataGridViewProdutosCaixa.TabIndex = 11;
            this.dataGridViewProdutosCaixa.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewProdutosCaixa_CellMouseClick);
            // 
            // textBoxlValorUnitario
            // 
            this.textBoxlValorUnitario.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxlValorUnitario.Location = new System.Drawing.Point(116, 328);
            this.textBoxlValorUnitario.Name = "textBoxlValorUnitario";
            this.textBoxlValorUnitario.Size = new System.Drawing.Size(111, 22);
            this.textBoxlValorUnitario.TabIndex = 4;
            this.textBoxlValorUnitario.TextChanged += new System.EventHandler(this.textBoxlValorUnitario_TextChanged);
            this.textBoxlValorUnitario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxlValorUnitario_KeyPress);
            // 
            // btnFecharCaixa
            // 
            this.btnFecharCaixa.BackColor = System.Drawing.Color.Silver;
            this.btnFecharCaixa.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFecharCaixa.BackgroundImage")));
            this.btnFecharCaixa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnFecharCaixa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFecharCaixa.FlatAppearance.BorderSize = 0;
            this.btnFecharCaixa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFecharCaixa.Font = new System.Drawing.Font("Tahoma", 32.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFecharCaixa.ForeColor = System.Drawing.SystemColors.WindowText;
            this.btnFecharCaixa.Location = new System.Drawing.Point(1317, -2);
            this.btnFecharCaixa.Name = "btnFecharCaixa";
            this.btnFecharCaixa.Size = new System.Drawing.Size(47, 45);
            this.btnFecharCaixa.TabIndex = 17;
            this.btnFecharCaixa.UseVisualStyleBackColor = false;
            // 
            // textBoxCodProduto
            // 
            this.textBoxCodProduto.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCodProduto.Location = new System.Drawing.Point(116, 208);
            this.textBoxCodProduto.Name = "textBoxCodProduto";
            this.textBoxCodProduto.Size = new System.Drawing.Size(111, 22);
            this.textBoxCodProduto.TabIndex = 1;
            this.textBoxCodProduto.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCodProduto_KeyDown);
            this.textBoxCodProduto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCodProduto_KeyPress);
            // 
            // lblTotalVenda
            // 
            this.lblTotalVenda.AutoSize = true;
            this.lblTotalVenda.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalVenda.Location = new System.Drawing.Point(15, 365);
            this.lblTotalVenda.Name = "lblTotalVenda";
            this.lblTotalVenda.Size = new System.Drawing.Size(56, 19);
            this.lblTotalVenda.TabIndex = 19;
            this.lblTotalVenda.Text = "Total: ";
            // 
            // maskedTextBoxValorTotalVenda
            // 
            this.maskedTextBoxValorTotalVenda.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxValorTotalVenda.Location = new System.Drawing.Point(116, 366);
            this.maskedTextBoxValorTotalVenda.Name = "maskedTextBoxValorTotalVenda";
            this.maskedTextBoxValorTotalVenda.Size = new System.Drawing.Size(85, 22);
            this.maskedTextBoxValorTotalVenda.TabIndex = 5;
            this.maskedTextBoxValorTotalVenda.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePrompt;
            // 
            // btnAdicionarProduto
            // 
            this.btnAdicionarProduto.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.btnAdicionarProduto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdicionarProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdicionarProduto.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionarProduto.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAdicionarProduto.Location = new System.Drawing.Point(714, 174);
            this.btnAdicionarProduto.Name = "btnAdicionarProduto";
            this.btnAdicionarProduto.Size = new System.Drawing.Size(97, 28);
            this.btnAdicionarProduto.TabIndex = 4;
            this.btnAdicionarProduto.Text = "Adicionar";
            this.btnAdicionarProduto.UseVisualStyleBackColor = false;
            this.btnAdicionarProduto.Click += new System.EventHandler(this.btnAdicionarProduto_Click);
            // 
            // btnFinalizarCompra
            // 
            this.btnFinalizarCompra.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.btnFinalizarCompra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFinalizarCompra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFinalizarCompra.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizarCompra.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnFinalizarCompra.Location = new System.Drawing.Point(835, 567);
            this.btnFinalizarCompra.Name = "btnFinalizarCompra";
            this.btnFinalizarCompra.Size = new System.Drawing.Size(90, 33);
            this.btnFinalizarCompra.TabIndex = 7;
            this.btnFinalizarCompra.Text = "Concluir";
            this.btnFinalizarCompra.UseVisualStyleBackColor = false;
            this.btnFinalizarCompra.Click += new System.EventHandler(this.btnFinalizarCompra_Click);
            // 
            // lblPesquisar
            // 
            this.lblPesquisar.AutoSize = true;
            this.lblPesquisar.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesquisar.Location = new System.Drawing.Point(374, 176);
            this.lblPesquisar.Name = "lblPesquisar";
            this.lblPesquisar.Size = new System.Drawing.Size(87, 19);
            this.lblPesquisar.TabIndex = 24;
            this.lblPesquisar.Text = "Pesquisar: ";
            // 
            // btnFecharJanela
            // 
            this.btnFecharJanela.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFecharJanela.BackgroundImage")));
            this.btnFecharJanela.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnFecharJanela.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFecharJanela.FlatAppearance.BorderSize = 0;
            this.btnFecharJanela.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFecharJanela.Location = new System.Drawing.Point(906, 1);
            this.btnFecharJanela.Name = "btnFecharJanela";
            this.btnFecharJanela.Size = new System.Drawing.Size(50, 42);
            this.btnFecharJanela.TabIndex = 25;
            this.btnFecharJanela.UseVisualStyleBackColor = true;
            this.btnFecharJanela.Click += new System.EventHandler(this.btnFecharJanela_Click);
            // 
            // lblTextCaixaAberto
            // 
            this.lblTextCaixaAberto.AutoSize = true;
            this.lblTextCaixaAberto.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTextCaixaAberto.Location = new System.Drawing.Point(16, 34);
            this.lblTextCaixaAberto.Name = "lblTextCaixaAberto";
            this.lblTextCaixaAberto.Size = new System.Drawing.Size(115, 42);
            this.lblTextCaixaAberto.TabIndex = 26;
            this.lblTextCaixaAberto.Text = "Caixa";
            // 
            // btnAdicionarProdutosEsquerda
            // 
            this.btnAdicionarProdutosEsquerda.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.btnAdicionarProdutosEsquerda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdicionarProdutosEsquerda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdicionarProdutosEsquerda.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionarProdutosEsquerda.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAdicionarProdutosEsquerda.Location = new System.Drawing.Point(18, 413);
            this.btnAdicionarProdutosEsquerda.Name = "btnAdicionarProdutosEsquerda";
            this.btnAdicionarProdutosEsquerda.Size = new System.Drawing.Size(108, 32);
            this.btnAdicionarProdutosEsquerda.TabIndex = 6;
            this.btnAdicionarProdutosEsquerda.Text = "Adicionar";
            this.btnAdicionarProdutosEsquerda.UseVisualStyleBackColor = false;
            this.btnAdicionarProdutosEsquerda.Click += new System.EventHandler(this.btnAdicionarProdutosEsquerda_Click);
            // 
            // lblQuantidade
            // 
            this.lblQuantidade.AutoSize = true;
            this.lblQuantidade.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantidade.Location = new System.Drawing.Point(14, 288);
            this.lblQuantidade.Name = "lblQuantidade";
            this.lblQuantidade.Size = new System.Drawing.Size(96, 19);
            this.lblQuantidade.TabIndex = 28;
            this.lblQuantidade.Text = "Quantidade:";
            // 
            // textBoxlQuantidadeProduto
            // 
            this.textBoxlQuantidadeProduto.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxlQuantidadeProduto.Location = new System.Drawing.Point(116, 289);
            this.textBoxlQuantidadeProduto.Name = "textBoxlQuantidadeProduto";
            this.textBoxlQuantidadeProduto.Size = new System.Drawing.Size(111, 22);
            this.textBoxlQuantidadeProduto.TabIndex = 3;
            this.textBoxlQuantidadeProduto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxlQuantidadeProduto_KeyPress);
            // 
            // comboBoxProdutos
            // 
            this.comboBoxProdutos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxProdutos.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxProdutos.FormattingEnabled = true;
            this.comboBoxProdutos.Location = new System.Drawing.Point(468, 176);
            this.comboBoxProdutos.Name = "comboBoxProdutos";
            this.comboBoxProdutos.Size = new System.Drawing.Size(211, 26);
            this.comboBoxProdutos.TabIndex = 30;
            this.comboBoxProdutos.MouseClick += new System.Windows.Forms.MouseEventHandler(this.comboBoxProdutos_MouseClick);
            // 
            // btnExcluirVenda
            // 
            this.btnExcluirVenda.BackColor = System.Drawing.Color.Red;
            this.btnExcluirVenda.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnExcluirVenda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExcluirVenda.FlatAppearance.BorderSize = 0;
            this.btnExcluirVenda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluirVenda.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluirVenda.ForeColor = System.Drawing.Color.White;
            this.btnExcluirVenda.Location = new System.Drawing.Point(841, 176);
            this.btnExcluirVenda.Name = "btnExcluirVenda";
            this.btnExcluirVenda.Size = new System.Drawing.Size(84, 26);
            this.btnExcluirVenda.TabIndex = 31;
            this.btnExcluirVenda.Text = "Excluir";
            this.btnExcluirVenda.UseVisualStyleBackColor = false;
            this.btnExcluirVenda.Click += new System.EventHandler(this.btnExcluirVenda_Click);
            // 
            // lblCodCaixa
            // 
            this.lblCodCaixa.AutoSize = true;
            this.lblCodCaixa.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodCaixa.Location = new System.Drawing.Point(171, 45);
            this.lblCodCaixa.Name = "lblCodCaixa";
            this.lblCodCaixa.Size = new System.Drawing.Size(0, 29);
            this.lblCodCaixa.TabIndex = 32;
            // 
            // lblTextTotal
            // 
            this.lblTextTotal.AutoSize = true;
            this.lblTextTotal.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTextTotal.Location = new System.Drawing.Point(15, 574);
            this.lblTextTotal.Name = "lblTextTotal";
            this.lblTextTotal.Size = new System.Drawing.Size(120, 19);
            this.lblTextTotal.TabIndex = 33;
            this.lblTextTotal.Text = "Total da venda:";
            // 
            // textBoxTotalVendaCompleta
            // 
            this.textBoxTotalVendaCompleta.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTotalVendaCompleta.Location = new System.Drawing.Point(141, 571);
            this.textBoxTotalVendaCompleta.Name = "textBoxTotalVendaCompleta";
            this.textBoxTotalVendaCompleta.Size = new System.Drawing.Size(100, 27);
            this.textBoxTotalVendaCompleta.TabIndex = 34;
            // 
            // btnFinalizarVenda
            // 
            this.btnFinalizarVenda.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.btnFinalizarVenda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFinalizarVenda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFinalizarVenda.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizarVenda.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnFinalizarVenda.Location = new System.Drawing.Point(282, 320);
            this.btnFinalizarVenda.Name = "btnFinalizarVenda";
            this.btnFinalizarVenda.Size = new System.Drawing.Size(90, 33);
            this.btnFinalizarVenda.TabIndex = 35;
            this.btnFinalizarVenda.Text = "Finalizar";
            this.btnFinalizarVenda.UseVisualStyleBackColor = false;
            this.btnFinalizarVenda.Click += new System.EventHandler(this.btnFinalizarVenda_Click);
            // 
            // lblFormaPagamento
            // 
            this.lblFormaPagamento.AutoSize = true;
            this.lblFormaPagamento.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormaPagamento.Location = new System.Drawing.Point(12, 207);
            this.lblFormaPagamento.Name = "lblFormaPagamento";
            this.lblFormaPagamento.Size = new System.Drawing.Size(99, 19);
            this.lblFormaPagamento.TabIndex = 36;
            this.lblFormaPagamento.Text = "Pagamento: ";
            // 
            // comboBoxFormaPagamento
            // 
            this.comboBoxFormaPagamento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFormaPagamento.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxFormaPagamento.FormattingEnabled = true;
            this.comboBoxFormaPagamento.Items.AddRange(new object[] {
            "Dinheiro",
            "Cartão de Crédito",
            "Cartão de Débito"});
            this.comboBoxFormaPagamento.Location = new System.Drawing.Point(141, 209);
            this.comboBoxFormaPagamento.Name = "comboBoxFormaPagamento";
            this.comboBoxFormaPagamento.Size = new System.Drawing.Size(121, 26);
            this.comboBoxFormaPagamento.TabIndex = 37;
            this.comboBoxFormaPagamento.SelectedIndexChanged += new System.EventHandler(this.comboBoxFormaPagamento_SelectedIndexChanged);
            // 
            // lblPagamento
            // 
            this.lblPagamento.AutoSize = true;
            this.lblPagamento.BackColor = System.Drawing.Color.Transparent;
            this.lblPagamento.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPagamento.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblPagamento.Location = new System.Drawing.Point(12, 248);
            this.lblPagamento.Name = "lblPagamento";
            this.lblPagamento.Size = new System.Drawing.Size(57, 19);
            this.lblPagamento.TabIndex = 38;
            this.lblPagamento.Text = "Valor: ";
            // 
            // textBoxValorPagamento
            // 
            this.textBoxValorPagamento.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxValorPagamento.Location = new System.Drawing.Point(141, 249);
            this.textBoxValorPagamento.Name = "textBoxValorPagamento";
            this.textBoxValorPagamento.Size = new System.Drawing.Size(111, 22);
            this.textBoxValorPagamento.TabIndex = 39;
            this.textBoxValorPagamento.TextChanged += new System.EventHandler(this.textBoxValorPagamento_TextChanged);
            this.textBoxValorPagamento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxValorPagamento_KeyPress);
            // 
            // lblTroco
            // 
            this.lblTroco.AutoSize = true;
            this.lblTroco.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTroco.Location = new System.Drawing.Point(12, 327);
            this.lblTroco.Name = "lblTroco";
            this.lblTroco.Size = new System.Drawing.Size(61, 19);
            this.lblTroco.TabIndex = 40;
            this.lblTroco.Text = "Troco: ";
            // 
            // textBoxTroco
            // 
            this.textBoxTroco.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTroco.Location = new System.Drawing.Point(141, 328);
            this.textBoxTroco.Name = "textBoxTroco";
            this.textBoxTroco.Size = new System.Drawing.Size(111, 22);
            this.textBoxTroco.TabIndex = 41;
            // 
            // textBoxTotalVenda
            // 
            this.textBoxTotalVenda.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTotalVenda.Location = new System.Drawing.Point(141, 289);
            this.textBoxTotalVenda.Name = "textBoxTotalVenda";
            this.textBoxTotalVenda.Size = new System.Drawing.Size(100, 27);
            this.textBoxTotalVenda.TabIndex = 43;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(12, 292);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(120, 19);
            this.lblTotal.TabIndex = 42;
            this.lblTotal.Text = "Total da venda:";
            // 
            // BtnCaixa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(949, 608);
            this.Controls.Add(this.textBoxTotalVenda);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.textBoxTroco);
            this.Controls.Add(this.lblTroco);
            this.Controls.Add(this.textBoxValorPagamento);
            this.Controls.Add(this.lblPagamento);
            this.Controls.Add(this.comboBoxFormaPagamento);
            this.Controls.Add(this.lblFormaPagamento);
            this.Controls.Add(this.btnFinalizarVenda);
            this.Controls.Add(this.textBoxTotalVendaCompleta);
            this.Controls.Add(this.lblTextTotal);
            this.Controls.Add(this.lblCodCaixa);
            this.Controls.Add(this.btnExcluirVenda);
            this.Controls.Add(this.comboBoxProdutos);
            this.Controls.Add(this.textBoxlQuantidadeProduto);
            this.Controls.Add(this.lblQuantidade);
            this.Controls.Add(this.btnAdicionarProdutosEsquerda);
            this.Controls.Add(this.lblTextCaixaAberto);
            this.Controls.Add(this.btnFecharJanela);
            this.Controls.Add(this.lblPesquisar);
            this.Controls.Add(this.btnFinalizarCompra);
            this.Controls.Add(this.btnAdicionarProduto);
            this.Controls.Add(this.maskedTextBoxValorTotalVenda);
            this.Controls.Add(this.lblTotalVenda);
            this.Controls.Add(this.textBoxCodProduto);
            this.Controls.Add(this.btnFecharCaixa);
            this.Controls.Add(this.textBoxlValorUnitario);
            this.Controls.Add(this.dataGridViewProdutosCaixa);
            this.Controls.Add(this.lblTextValorUnitario);
            this.Controls.Add(this.textBoxNomeProd);
            this.Controls.Add(this.lblTxtnomeProduto);
            this.Controls.Add(this.lblTextCodVenda);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.ImeMode = System.Windows.Forms.ImeMode.KatakanaHalf;
            this.Location = new System.Drawing.Point(300, 80);
            this.Name = "BtnCaixa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Tela Caixa";
            this.TransparencyKey = System.Drawing.Color.Snow;
            this.Load += new System.EventHandler(this.BtnCaixa_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProdutosCaixa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTextCodVenda;
        private System.Windows.Forms.Label lblTxtnomeProduto;
        private System.Windows.Forms.TextBox textBoxNomeProd;
        private System.Windows.Forms.Label lblTextValorUnitario;
        private System.Windows.Forms.DataGridView dataGridViewProdutosCaixa;
        private System.Windows.Forms.TextBox textBoxlValorUnitario;
        private System.Windows.Forms.Button btnFecharCaixa;
        private System.Windows.Forms.TextBox textBoxCodProduto;
        private System.Windows.Forms.Label lblTotalVenda;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxValorTotalVenda;
        private System.Windows.Forms.Button btnAdicionarProduto;
        private System.Windows.Forms.Button btnFinalizarCompra;
        private System.Windows.Forms.Label lblPesquisar;
        private System.Windows.Forms.Label lblTextCaixaAberto;
        public System.Windows.Forms.Button btnFecharJanela;
        private System.Windows.Forms.Button btnAdicionarProdutosEsquerda;
        private System.Windows.Forms.Label lblQuantidade;
        private System.Windows.Forms.TextBox textBoxlQuantidadeProduto;
        private System.Windows.Forms.Button btnExcluirVenda;
        public System.Windows.Forms.ComboBox comboBoxProdutos;
        private System.Windows.Forms.Label lblCodCaixa;
        private System.Windows.Forms.Label lblTextTotal;
        private System.Windows.Forms.TextBox textBoxTotalVendaCompleta;
        private System.Windows.Forms.Button btnFinalizarVenda;
        private System.Windows.Forms.Label lblFormaPagamento;
        private System.Windows.Forms.ComboBox comboBoxFormaPagamento;
        private System.Windows.Forms.Label lblPagamento;
        private System.Windows.Forms.TextBox textBoxValorPagamento;
        private System.Windows.Forms.Label lblTroco;
        private System.Windows.Forms.TextBox textBoxTroco;
        private System.Windows.Forms.TextBox textBoxTotalVenda;
        private System.Windows.Forms.Label lblTotal;
    }
}