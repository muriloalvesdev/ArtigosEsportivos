﻿namespace Pim3Semestre_Original_
{
    partial class TelaCadastroClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaCadastroClientes));
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxBairro = new System.Windows.Forms.TextBox();
            this.maskedTextBoxTelFixo = new System.Windows.Forms.MaskedTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.MaskedTextBoxCelCelular = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBoxCep = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxCpf = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxDataNascimento = new System.Windows.Forms.MaskedTextBox();
            this.btnFecharJanela = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxComplemento = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxLogradouro = new System.Windows.Forms.TextBox();
            this.comboBoxSexo = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxEstados = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxCliente = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnCancelarCadastro = new System.Windows.Forms.Button();
            this.btnConcluirCadastro = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBoxCidades = new System.Windows.Forms.ComboBox();
            this.dataGridViewControleCliente = new System.Windows.Forms.DataGridView();
            this.btnExcluirCliente = new System.Windows.Forms.Button();
            this.btnAtualizarCadastro = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewControleCliente)).BeginInit();
            this.SuspendLayout();
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(726, 252);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(55, 18);
            this.label13.TabIndex = 72;
            this.label13.Text = "Bairro: ";
            // 
            // textBoxBairro
            // 
            this.textBoxBairro.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxBairro.Location = new System.Drawing.Point(818, 252);
            this.textBoxBairro.Name = "textBoxBairro";
            this.textBoxBairro.Size = new System.Drawing.Size(162, 22);
            this.textBoxBairro.TabIndex = 9;
            // 
            // maskedTextBoxTelFixo
            // 
            this.maskedTextBoxTelFixo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxTelFixo.Location = new System.Drawing.Point(539, 208);
            this.maskedTextBoxTelFixo.Name = "maskedTextBoxTelFixo";
            this.maskedTextBoxTelFixo.Size = new System.Drawing.Size(100, 22);
            this.maskedTextBoxTelFixo.TabIndex = 5;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(425, 208);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 18);
            this.label12.TabIndex = 70;
            this.label12.Text = "Fixo: ";
            // 
            // MaskedTextBoxCelCelular
            // 
            this.MaskedTextBoxCelCelular.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaskedTextBoxCelCelular.Location = new System.Drawing.Point(158, 208);
            this.MaskedTextBoxCelCelular.Name = "MaskedTextBoxCelCelular";
            this.MaskedTextBoxCelCelular.Size = new System.Drawing.Size(114, 22);
            this.MaskedTextBoxCelCelular.TabIndex = 4;
            // 
            // MaskedTextBoxCep
            // 
            this.MaskedTextBoxCep.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaskedTextBoxCep.Location = new System.Drawing.Point(818, 296);
            this.MaskedTextBoxCep.Name = "MaskedTextBoxCep";
            this.MaskedTextBoxCep.Size = new System.Drawing.Size(83, 22);
            this.MaskedTextBoxCep.TabIndex = 12;
            // 
            // maskedTextBoxCpf
            // 
            this.maskedTextBoxCpf.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxCpf.Location = new System.Drawing.Point(818, 208);
            this.maskedTextBoxCpf.Name = "maskedTextBoxCpf";
            this.maskedTextBoxCpf.Size = new System.Drawing.Size(100, 22);
            this.maskedTextBoxCpf.TabIndex = 6;
            // 
            // maskedTextBoxDataNascimento
            // 
            this.maskedTextBoxDataNascimento.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxDataNascimento.Location = new System.Drawing.Point(818, 168);
            this.maskedTextBoxDataNascimento.Name = "maskedTextBoxDataNascimento";
            this.maskedTextBoxDataNascimento.Size = new System.Drawing.Size(80, 22);
            this.maskedTextBoxDataNascimento.TabIndex = 3;
            // 
            // btnFecharJanela
            // 
            this.btnFecharJanela.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFecharJanela.BackgroundImage")));
            this.btnFecharJanela.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnFecharJanela.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFecharJanela.FlatAppearance.BorderSize = 0;
            this.btnFecharJanela.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFecharJanela.Location = new System.Drawing.Point(940, 12);
            this.btnFecharJanela.Name = "btnFecharJanela";
            this.btnFecharJanela.Size = new System.Drawing.Size(50, 42);
            this.btnFecharJanela.TabIndex = 16;
            this.btnFecharJanela.UseVisualStyleBackColor = true;
            this.btnFecharJanela.Click += new System.EventHandler(this.btnFecharJanela_Click_1);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(32, 208);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 18);
            this.label11.TabIndex = 68;
            this.label11.Text = "Celular: ";
            // 
            // textBoxComplemento
            // 
            this.textBoxComplemento.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxComplemento.Location = new System.Drawing.Point(539, 296);
            this.textBoxComplemento.Name = "textBoxComplemento";
            this.textBoxComplemento.Size = new System.Drawing.Size(148, 23);
            this.textBoxComplemento.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(425, 296);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 18);
            this.label10.TabIndex = 67;
            this.label10.Text = "Complemento: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(726, 301);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 18);
            this.label8.TabIndex = 65;
            this.label8.Text = "CEP: ";
            // 
            // textBoxLogradouro
            // 
            this.textBoxLogradouro.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLogradouro.Location = new System.Drawing.Point(158, 295);
            this.textBoxLogradouro.Name = "textBoxLogradouro";
            this.textBoxLogradouro.Size = new System.Drawing.Size(195, 23);
            this.textBoxLogradouro.TabIndex = 10;
            // 
            // comboBoxSexo
            // 
            this.comboBoxSexo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSexo.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxSexo.FormattingEnabled = true;
            this.comboBoxSexo.Items.AddRange(new object[] {
            "Masculino",
            "Feminino"});
            this.comboBoxSexo.Location = new System.Drawing.Point(539, 162);
            this.comboBoxSexo.Name = "comboBoxSexo";
            this.comboBoxSexo.Size = new System.Drawing.Size(82, 24);
            this.comboBoxSexo.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(726, 168);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 18);
            this.label7.TabIndex = 64;
            this.label7.Text = "Data Nasc.:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(32, 252);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 18);
            this.label6.TabIndex = 63;
            this.label6.Text = "Estado: ";
            // 
            // comboBoxEstados
            // 
            this.comboBoxEstados.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEstados.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxEstados.FormattingEnabled = true;
            this.comboBoxEstados.Location = new System.Drawing.Point(158, 252);
            this.comboBoxEstados.Name = "comboBoxEstados";
            this.comboBoxEstados.Size = new System.Drawing.Size(56, 22);
            this.comboBoxEstados.TabIndex = 7;
            this.comboBoxEstados.TextChanged += new System.EventHandler(this.comboBoxEstados_TextChanged);
            this.comboBoxEstados.MouseClick += new System.Windows.Forms.MouseEventHandler(this.comboBoxEstados_MouseClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(32, 296);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 18);
            this.label4.TabIndex = 62;
            this.label4.Text = "Logradouro: ";
            // 
            // textBoxCliente
            // 
            this.textBoxCliente.BackColor = System.Drawing.Color.White;
            this.textBoxCliente.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCliente.Location = new System.Drawing.Point(158, 167);
            this.textBoxCliente.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxCliente.Name = "textBoxCliente";
            this.textBoxCliente.Size = new System.Drawing.Size(195, 22);
            this.textBoxCliente.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(32, 167);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 18);
            this.label3.TabIndex = 61;
            this.label3.Text = "Nome completo: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(425, 167);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 18);
            this.label2.TabIndex = 60;
            this.label2.Text = "Sexo: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(726, 208);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 18);
            this.label1.TabIndex = 59;
            this.label1.Text = "CPF: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(28, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 42);
            this.label5.TabIndex = 58;
            this.label5.Text = "Cliente";
            // 
            // btnCancelarCadastro
            // 
            this.btnCancelarCadastro.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.btnCancelarCadastro.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCancelarCadastro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelarCadastro.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCancelarCadastro.FlatAppearance.BorderSize = 0;
            this.btnCancelarCadastro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelarCadastro.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarCadastro.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnCancelarCadastro.Location = new System.Drawing.Point(743, 360);
            this.btnCancelarCadastro.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancelarCadastro.Name = "btnCancelarCadastro";
            this.btnCancelarCadastro.Size = new System.Drawing.Size(88, 27);
            this.btnCancelarCadastro.TabIndex = 14;
            this.btnCancelarCadastro.Text = "Cancelar";
            this.btnCancelarCadastro.UseVisualStyleBackColor = false;
            this.btnCancelarCadastro.Click += new System.EventHandler(this.btnCancelarCadastro_Click_1);
            // 
            // btnConcluirCadastro
            // 
            this.btnConcluirCadastro.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.btnConcluirCadastro.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnConcluirCadastro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConcluirCadastro.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnConcluirCadastro.FlatAppearance.BorderSize = 0;
            this.btnConcluirCadastro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConcluirCadastro.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConcluirCadastro.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnConcluirCadastro.Location = new System.Drawing.Point(882, 360);
            this.btnConcluirCadastro.Margin = new System.Windows.Forms.Padding(4);
            this.btnConcluirCadastro.Name = "btnConcluirCadastro";
            this.btnConcluirCadastro.Size = new System.Drawing.Size(92, 27);
            this.btnConcluirCadastro.TabIndex = 13;
            this.btnConcluirCadastro.Text = "Salvar";
            this.btnConcluirCadastro.UseVisualStyleBackColor = false;
            this.btnConcluirCadastro.Click += new System.EventHandler(this.btnConcluirCadastro_Click_1);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(425, 252);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 18);
            this.label9.TabIndex = 66;
            this.label9.Text = "Cidade: ";
            // 
            // comboBoxCidades
            // 
            this.comboBoxCidades.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCidades.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxCidades.FormattingEnabled = true;
            this.comboBoxCidades.Location = new System.Drawing.Point(539, 252);
            this.comboBoxCidades.Name = "comboBoxCidades";
            this.comboBoxCidades.Size = new System.Drawing.Size(128, 22);
            this.comboBoxCidades.TabIndex = 8;
            // 
            // dataGridViewControleCliente
            // 
            this.dataGridViewControleCliente.AllowUserToAddRows = false;
            this.dataGridViewControleCliente.AllowUserToDeleteRows = false;
            this.dataGridViewControleCliente.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewControleCliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewControleCliente.Location = new System.Drawing.Point(35, 404);
            this.dataGridViewControleCliente.Name = "dataGridViewControleCliente";
            this.dataGridViewControleCliente.ReadOnly = true;
            this.dataGridViewControleCliente.Size = new System.Drawing.Size(941, 212);
            this.dataGridViewControleCliente.TabIndex = 74;
            this.dataGridViewControleCliente.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewControleCliente_CellMouseClick);
            this.dataGridViewControleCliente.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewControleCliente_CellMouseDoubleClick);
            // 
            // btnExcluirCliente
            // 
            this.btnExcluirCliente.BackColor = System.Drawing.Color.Red;
            this.btnExcluirCliente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnExcluirCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExcluirCliente.FlatAppearance.BorderSize = 0;
            this.btnExcluirCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluirCliente.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluirCliente.ForeColor = System.Drawing.Color.White;
            this.btnExcluirCliente.Location = new System.Drawing.Point(896, 622);
            this.btnExcluirCliente.Name = "btnExcluirCliente";
            this.btnExcluirCliente.Size = new System.Drawing.Size(84, 30);
            this.btnExcluirCliente.TabIndex = 15;
            this.btnExcluirCliente.Text = "Excluir";
            this.btnExcluirCliente.UseVisualStyleBackColor = false;
            this.btnExcluirCliente.Click += new System.EventHandler(this.btnExcluirCliente_Click);
            // 
            // btnAtualizarCadastro
            // 
            this.btnAtualizarCadastro.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.btnAtualizarCadastro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAtualizarCadastro.FlatAppearance.BorderSize = 0;
            this.btnAtualizarCadastro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAtualizarCadastro.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtualizarCadastro.ForeColor = System.Drawing.Color.White;
            this.btnAtualizarCadastro.Location = new System.Drawing.Point(882, 360);
            this.btnAtualizarCadastro.Name = "btnAtualizarCadastro";
            this.btnAtualizarCadastro.Size = new System.Drawing.Size(92, 26);
            this.btnAtualizarCadastro.TabIndex = 75;
            this.btnAtualizarCadastro.Text = "Atualizar";
            this.btnAtualizarCadastro.UseVisualStyleBackColor = false;
            this.btnAtualizarCadastro.Click += new System.EventHandler(this.btnAtualizarCadastro_Click);
            // 
            // TelaCadastroClientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1002, 663);
            this.Controls.Add(this.btnAtualizarCadastro);
            this.Controls.Add(this.btnExcluirCliente);
            this.Controls.Add(this.dataGridViewControleCliente);
            this.Controls.Add(this.comboBoxCidades);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.textBoxBairro);
            this.Controls.Add(this.maskedTextBoxTelFixo);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.MaskedTextBoxCelCelular);
            this.Controls.Add(this.MaskedTextBoxCep);
            this.Controls.Add(this.maskedTextBoxCpf);
            this.Controls.Add(this.maskedTextBoxDataNascimento);
            this.Controls.Add(this.btnFecharJanela);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBoxComplemento);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBoxLogradouro);
            this.Controls.Add(this.comboBoxSexo);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comboBoxEstados);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxCliente);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnCancelarCadastro);
            this.Controls.Add(this.btnConcluirCadastro);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(250, 60);
            this.Name = "TelaCadastroClientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Cadastro de clientes";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewControleCliente)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label13;
        public System.Windows.Forms.MaskedTextBox maskedTextBoxTelFixo;
        private System.Windows.Forms.Label label12;
        public System.Windows.Forms.MaskedTextBox MaskedTextBoxCelCelular;
        public System.Windows.Forms.MaskedTextBox MaskedTextBoxCep;
        public System.Windows.Forms.MaskedTextBox maskedTextBoxCpf;
        public System.Windows.Forms.MaskedTextBox maskedTextBoxDataNascimento;
        private System.Windows.Forms.Button btnFecharJanela;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.TextBox textBoxComplemento;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        public System.Windows.Forms.TextBox textBoxLogradouro;
        public System.Windows.Forms.ComboBox comboBoxSexo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.ComboBox comboBoxEstados;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox textBoxCliente;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnCancelarCadastro;
        private System.Windows.Forms.Button btnConcluirCadastro;
        public System.Windows.Forms.TextBox textBoxBairro;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBoxCidades;
        private System.Windows.Forms.Button btnExcluirCliente;
        public System.Windows.Forms.DataGridView dataGridViewControleCliente;
        private System.Windows.Forms.Button btnAtualizarCadastro;
    }
}